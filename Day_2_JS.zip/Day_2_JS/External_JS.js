var a=30;
var b=20;
var c=a+b;


document.write("Sum of a+b is:-",c);