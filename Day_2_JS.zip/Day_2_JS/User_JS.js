var name = prompt("What is Your Name:-");
document.write(name);